# It contains all the functions: response with sources, response without sources, get similar chunks, raw LLM response, answer to QA

import os
import sys
from dotenv import load_dotenv, find_dotenv
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain_core.globals import set_verbose, set_debug
import warnings

# Load environment variables
load_dotenv(find_dotenv())

# Check for correct arguments
# if len(sys.argv) != 2:
#     print("Usage: python item_02_generate_citations_FAISS.py <path_to_working_directory>")
#     sys.exit(1)

# working_dir = sys.argv[1]
# faiss_index_path = os.path.join(working_dir, "faiss_index")

# Validate existence of working directory
# if not os.path.isdir(working_dir):
#     print(f"The provided path is not a valid file: {working_dir}")
#     sys.exit(1)

warnings.filterwarnings("ignore", message=".*LangChainDeprecationWarning.*")

# Disable verbose and debug logging
set_verbose(False)
set_debug(False)

def process_llm_response_with_sources(llm_response):
    result = llm_response['result'].strip().lower()
    result = result.split(".")[0]
    # Check if the response is a variation of "I don't know"
    if result in ["i don't know", "i do not know", "unknown", "i'm not sure", "i am not sure"]:
        return result.capitalize()
    
    return_txt = llm_response['result']
    return_txt += '\nSources:'
    
    # Use a set to keep track of unique sources
    unique_sources = set()
    
    for source in llm_response["source_documents"]:
        citation = source.metadata['source']
        # Only add the citation if it's not already in the set
        if citation not in unique_sources:
            return_txt += f"\n \n{citation}"
            unique_sources.add(citation)
    
    return return_txt

def process_llm_response(llm_response):
    result = llm_response['result'].strip().lower()
    result = result.split(".")[0]
    # Check if the response is a variation of "I don't know"
    if result in ["i don't know", "i do not know", "unknown", "i'm not sure", "i am not sure"]:
        return result.capitalize()
    
    return_txt = llm_response['result']

    return return_txt

def get_similar_chunks(raw_llm_response):

    similar_chunks = []
    for doc in raw_llm_response["source_documents"]:
        similar_chunks.append(doc.page_content)
    
    return similar_chunks

def raw_LLM_response(query, working_dir):
    try:
        embedding = OpenAIEmbeddings(api_key=os.getenv("OPENAI_API_KEY"))
        
        # First try with the passed working_dir and faiss_index subdirectory
        faiss_index_path = os.path.join(working_dir, "faiss_index")
        
        # Check if the path exists, otherwise try direct path
        if not os.path.exists(os.path.join(faiss_index_path, "index.faiss")):
            print(f"FAISS index not found at {faiss_index_path}/index.faiss")
            # Try direct paths to the index files
            if os.path.exists(os.path.join(working_dir, "index.faiss")):
                print(f"Found FAISS index at {working_dir}/index.faiss")
                faiss_index_path = working_dir
            else:
                raise FileNotFoundError(f"Could not find index.faiss in {faiss_index_path} or {working_dir}")
        
        print(f"Loading FAISS index from {faiss_index_path}")
        # Load the FAISS index
        vectordb = FAISS.load_local(faiss_index_path, embedding, allow_dangerous_deserialization=True)

        retriever = vectordb.as_retriever()

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

        # Create the chain to answer questions
        qa_chain = RetrievalQA.from_chain_type(
            llm,
            chain_type="stuff",
            retriever=retriever,
            return_source_documents=True
        )

        llm_response = qa_chain.invoke(query)
        return llm_response
    
    except Exception as e:
        print(f"Error in raw_LLM_response: {str(e)}")
        # Return a structured response even in case of error
        return {
            "result": f"I encountered an error while retrieving information: {str(e)}",
            "source_documents": []
        }

def answer_to_QA(query, working_dir):

    llm_response = raw_LLM_response(query, working_dir)
    answer_txt = process_llm_response_with_sources(llm_response)

    return answer_txt


if __name__ == "__main__":
    # query = "How parastites are damaging the corals?"
    query = "Split the given content up into 10 individual modules to make a full educational course"
    
    # llm_response = raw_LLM_response(query)

    # similar_chunk_list = get_similar_chunks(llm_response)
    
    # print(process_llm_response(llm_response))

    # print(similar_chunk_list)

    print(answer_to_QA(query))