import os
import pandas as pd
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.prompts import ChatPromptTemplate
from langchain_community.vectorstores import FAISS
from dotenv import load_dotenv
import re

# Load environment variables
load_dotenv()

# Constants
WORKING_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
VECTOR_STORE_PATH = os.path.join(WORKING_DIR, "faiss_index")
LLM_MODEL = "gpt-4o-mini"
EVALUATION_DIR = os.path.join(WORKING_DIR, "evaluation")

# Create evaluation directory if it doesn't exist
os.makedirs(EVALUATION_DIR, exist_ok=True)

def load_sample_questions() -> str:
    """Load sample questions for few-shot learning."""
    with open(os.path.join(EVALUATION_DIR, "Sample_questions.txt"), "r") as f:
        return f.read()

def create_question_generation_prompt() -> ChatPromptTemplate:
    """Create prompt template for question generation."""
    sample_questions = load_sample_questions()
    
    template = f"""You are an expert at generating high-quality questions for scientific research papers.
    Use the following examples as a guide for question quality and style:

    {sample_questions}

    Based on the following document content, generate 5 high-quality questions that:
    1. Are specific and focused
    2. Require analysis and synthesis
    3. Could lead to meaningful insights
    4. Are relevant to coral research
    5. Can be answered from the provided content

    Document Content:
    {{content}}

    Generate questions in the following format:
    Q1: [Question]
    Q2: [Question]
    Q3: [Question]
    Q4: [Question]
    Q5: [Question]"""

    return ChatPromptTemplate.from_messages([
        ("system", template)
    ])

def create_question_rating_prompt() -> ChatPromptTemplate:
    """Create prompt template for rating questions."""
    template = """You are an expert at evaluating questions about coral reefs and marine ecosystems.
    Rate each question on a scale of 1-5 based on:
    1. Clarity and precision
    2. Depth of understanding required
    3. Relevance to coral reef science
    4. Potential for detailed answers
    5. Educational value

    IMPORTANT: Provide ONLY numeric ratings (1-5) in the following format:
    Q1: 4
    Q2: 5
    Q3: 3
    Q4: 4
    Q5: 5

    Questions to rate:
    {questions}"""

    return ChatPromptTemplate.from_messages([
        ("system", template)
    ])

class QuestionGenerator:
    def __init__(self):
        self.llm = ChatOpenAI(model=LLM_MODEL, temperature=0.7)
        self.embeddings = OpenAIEmbeddings()
        self.vector_store = FAISS.load_local(
            VECTOR_STORE_PATH, 
            self.embeddings,
            allow_dangerous_deserialization=True
        )
        self.question_prompt = create_question_generation_prompt()
        self.rating_prompt = create_question_rating_prompt()

    def generate_questions(self, content: str) -> list:
        """Generate questions from content."""
        chain = self.question_prompt | self.llm
        response = chain.invoke({"content": content})
        
        # Parse questions from response
        questions = []
        for line in response.content.split('\n'):
            if line.strip().startswith('Q'):
                question = line.split(':', 1)[1].strip()
                questions.append(question)
        
        return questions

    def rate_questions(self, questions: list) -> list:
        """Rate questions on a scale of 1-5."""
        chain = self.rating_prompt | self.llm
        response = chain.invoke({"questions": '\n'.join(questions)})
        
        # Parse ratings from response
        ratings = []
        for line in response.content.split('\n'):
            if line.strip().startswith('Q'):
                try:
                    # Extract just the number from the line
                    rating_text = line.split(':')[1].strip()
                    # Find the first number in the text
                    numbers = re.findall(r'\d+', rating_text)
                    if numbers:
                        rating = float(numbers[0])
                        # Ensure rating is between 1 and 5
                        rating = max(1, min(5, rating))
                        ratings.append(rating)
                    else:
                        print(f"Warning: No number found in rating line: {line}")
                        ratings.append(3.0)  # Default to middle rating
                except Exception as e:
                    print(f"Warning: Could not parse rating from line: {line}")
                    ratings.append(3.0)  # Default to middle rating
        
        # Ensure we have a rating for each question
        while len(ratings) < len(questions):
            ratings.append(3.0)  # Default to middle rating for any missing ratings
        
        return ratings

def main():
    # Initialize question generator
    generator = QuestionGenerator()
    
    # Get all documents from FAISS index
    docs = generator.vector_store.similarity_search("", k=50)  # Get a large number of docs
    
    all_questions = []
    all_ratings = []
    all_sources = []  # Track source documents
    
    print(f"Processing {len(docs)} documents...")
    
    for i, doc in enumerate(docs, 1):
        print(f"Processing document {i}/{len(docs)}")
        
        # Generate questions
        questions = generator.generate_questions(doc.page_content)
        
        # Rate questions
        ratings = generator.rate_questions(questions)
        
        # Ensure we have matching lengths
        if len(questions) != len(ratings):
            print(f"Warning: Mismatch in questions ({len(questions)}) and ratings ({len(ratings)}) for document {i}")
            # Pad or truncate ratings to match questions length
            if len(ratings) < len(questions):
                ratings.extend([3.0] * (len(questions) - len(ratings)))
            else:
                ratings = ratings[:len(questions)]
        
        # Store questions, ratings, and sources
        all_questions.extend(questions)
        all_ratings.extend(ratings)
        all_sources.extend([doc.metadata.get('source', 'Unknown')] * len(questions))
    
    # Verify lengths match before creating DataFrame
    if not (len(all_questions) == len(all_ratings) == len(all_sources)):
        print(f"Error: Length mismatch - Questions: {len(all_questions)}, Ratings: {len(all_ratings)}, Sources: {len(all_sources)}")
        return
    
    # Create DataFrame with all questions
    df_all = pd.DataFrame({
        'Question': all_questions,
        'Rating': all_ratings,
        'Source': all_sources
    })
    
    # Create DataFrame with questions rated 3 or higher
    df_filtered = df_all[df_all['Rating'] >= 3].copy()
    
    # Save results
    all_questions_path = os.path.join(EVALUATION_DIR, "all_questions.csv")
    filtered_questions_path = os.path.join(EVALUATION_DIR, "high_rated_questions.csv")
    
    df_all.to_csv(all_questions_path, index=False, encoding='utf-8')
    df_filtered.to_csv(filtered_questions_path, index=False, encoding='utf-8')
    
    print(f"\nResults:")
    print(f"Generated {len(df_all)} questions")
    print(f"Found {len(df_filtered)} questions rated 3 or higher")
    print(f"Saved all questions to {all_questions_path}")
    print(f"Saved high-rated questions to {filtered_questions_path}")

if __name__ == "__main__":
    main() 
