from datetime import date, datetime
import os
import firebase_admin
from firebase_admin import auth, credentials
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import faiss
import pickle
import numpy as np
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.db.schema import Base, Suggestion, User, Document, Chat, Message, Vote, Onboarding
from alembic import command
from alembic.config import Config
import uuid
from openai import OpenAI
from sqlalchemy.sql import text
from src.utils.dev_mode import ensure_dev_user
import json

from src.db.queries import (
    delete_documents_by_id_after_timestamp, get_user_by_email, create_user, save_chat, delete_chat_by_id, 
    get_chats_by_user_id, get_chat_by_id, save_messages, get_messages_by_chat_id, vote_message,
    get_votes_by_chat_id, save_document, get_documents_by_id, get_document_by_id,
    delete_messages_by_chat_id_after_timestamp, update_chat_visibility_by_id, 
    create_onboarding, get_user_by_firebase_uid, get_suggestions_by_document_id, save_suggestions,
    get_message_by_id
)

load_dotenv()

# Initialize Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key')  # Use environment variable in production
is_production = os.getenv("ENVIRONMENT") == "production"
app.config['SESSION_COOKIE_SECURE'] = is_production
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Configure CORS
ALLOWED_ORIGINS = [
    "http://localhost:3000", 
    "http://localhost:3002", 
    "http://localhost:3003", 
    "http://localhost:8081", 
    "https://linkx-6bdcd.web.app", 
    "https://coralx.ai", 
    "https://safetyscan.live",
    "https://www.safetyscan.live",
    "https://coralxai-7a7ef.web.app",
    "https://coralxai-7a7ef.firebaseapp.com"
]

# Add production domains from environment variable if available
PRODUCTION_DOMAIN = os.getenv("PRODUCTION_DOMAIN")
if PRODUCTION_DOMAIN:
    # Handle comma-separated list of domains
    production_domains = [domain.strip() for domain in PRODUCTION_DOMAIN.split(',')]
    ALLOWED_ORIGINS.extend(production_domains)

CORS(app, 
     resources={r"/*": {"origins": ALLOWED_ORIGINS}},
     supports_credentials=True,
     allow_headers=['Content-Type', 'Authorization', 'Cookie', 'X-Requested-With'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Set additional headers for all responses
@app.after_request
def after_request(response):
    origin = request.headers.get('Origin')
    if origin in ALLOWED_ORIGINS:
        # Set CORS headers without trying to remove them first
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Access-Control-Allow-Credentials'] = 'true'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization,Cookie,X-Requested-With'
        response.headers['Access-Control-Allow-Methods'] = 'GET,PUT,POST,DELETE,OPTIONS'
        response.headers['Access-Control-Expose-Headers'] = 'Content-Type,Authorization,Set-Cookie'
    return response

# Initialize Firebase Admin
try:
    cred = credentials.Certificate("firebaseKey.json")
    firebase_admin.initialize_app(cred)
    print("Firebase initialized successfully")
except Exception as e:
    print(f"Error initializing Firebase: {e}")
    print("Running in development mode without Firebase authentication")

# SQLAlchemy configuration
POSTGRES_URL = os.getenv("POSTGRES_URL")
if not POSTGRES_URL:
    raise ValueError("POSTGRES_URL is not defined in the environment")

# Ensure URL starts with postgresql:// instead of postgres://
if POSTGRES_URL.startswith('postgres://'):
    POSTGRES_URL = POSTGRES_URL.replace('postgres://', 'postgresql://', 1)

# Create engine, session, and tables
engine = create_engine(POSTGRES_URL)
Session = sessionmaker(bind=engine, expire_on_commit=False)
Base.metadata.create_all(engine)

# Run migration SQL script for existing databases
try:
    with open('migration.sql', 'r') as migration_file:
        migration_sql = migration_file.read()
        with engine.connect() as connection:
            connection.execute(text(migration_sql))
            connection.commit()
    print("Migration completed successfully.")
except Exception as e:
    print(f"Migration error: {e}")

# FAISS and metadata paths
INDEX_PATH = "/app/"
PICKLE_PATH = "/app/"

# Attempt to load FAISS index
try:
    faiss_index = faiss.read_index("/app/index.faiss")
    print("FAISS index successfully loaded from /app/index.faiss")
except Exception as e:
    print(f"Error loading FAISS index: {e}")
    faiss_index = None

# Attempt to load metadata
try:
    with open("/app/index.pkl", "rb") as f:
        metadata = pickle.load(f)
    print("Metadata successfully loaded from /app/index.pkl")
except Exception as e:
    print(f"Error loading metadata: {e}")
    metadata = None


# This one returns plain data — safe to use in backend logic like chat
def get_user_from_session():
    """Get user from session cookie"""
    try:
        # Get session cookie from request
        session_cookie = request.cookies.get('session')
        if not session_cookie:
            return None, "No session cookie found", 401

        # Verify the session cookie
        try:
            decoded_claims = auth.verify_session_cookie(session_cookie)
        except Exception as e:
            print(f"Error verifying session cookie: {str(e)}")
            return None, "Invalid session cookie", 401

        # Get user from database
        db_session = Session()
        user = db_session.query(User).filter(User.firebase_uid == decoded_claims['uid']).first()
        if not user:
            return None, "User not found", 404

        return user, None, None
    except Exception as e:
        print(f"Error in get_user_from_session: {str(e)}")
        return None, str(e), 500

# This one is for routes your teammates use — returns Flask-style response
def verify_session_cookie():
    """Verify session cookie and return user claims"""
    try:
        session_cookie = request.cookies.get('session')
        if not session_cookie:
            return jsonify({"error": "No session cookie found"}), 401

        decoded_claims = auth.verify_session_cookie(session_cookie)
        return decoded_claims
    except Exception as e:
        print(f"Error verifying session cookie: {str(e)}")
        return jsonify({"error": "Invalid session cookie"}), 401



# Unprotected Routes
@app.route('/')
def home():
    """Serve the main UI."""
    return render_template('index.html')

@app.route('/citations', methods=['GET'])
def citations():
    """Example unprotected route that returns citation data (if you want it public)."""
    try:
        citation_data = []
        if metadata:
            for idx, doc in enumerate(metadata.values()):
                citation_data.append({
                    "source": doc.metadata.get("source", "Unknown"),
                    "citation": f"Mock APA Citation for Document {idx + 1}"
                })
        return jsonify({"citations": citation_data})
    except Exception as e:
        return jsonify({"error": f"Error generating citations: {e}"}), 500

@app.route('/migrate', methods=['POST'])
def migrate():
    """Run Alembic migrations (optionally protected if needed)."""
    # If you want to protect migrations, uncomment the following:
    # user = verify_session_cookie()
    # if isinstance(user, dict) and "error" in user:
    #     return user

    try:
        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", POSTGRES_URL)

        print("⏳ Running migrations...")
        command.upgrade(alembic_cfg, "head")
        print("✅ Migrations completed.")

        return jsonify({"message": "Migrations completed successfully!"}), 200
    except Exception as e:
        return jsonify({"error": f"Error running migrations: {str(e)}"}), 500


# Protected Routes

@app.route('/onboarding', methods=['POST'])
def create_onboarding_route():
    user_claims = verify_session_cookie()
    if isinstance(user_claims, dict) and "error" in user_claims:
        return user_claims

    firebase_uid = user_claims["uid"]

    db_session = Session()
    postgres_user = get_user_by_firebase_uid(db_session, firebase_uid)
    if not postgres_user:
        return jsonify({"error": "User not found in database"}), 404

    data = request.get_json()
    required_fields = ["name", "answers", "quizzes"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing required fields"}), 400

    try:
        new_onboarding = create_onboarding(
            db=db_session,
            user_id=postgres_user.id,
            name=data["name"],
            answers=data["answers"],
            quizzes=data["quizzes"]
        )
        return jsonify({
            "message": "Onboarding record created",
            "id": str(new_onboarding.id)
        }), 201
    except Exception as e:
        print("Error creating onboarding record:", e)
        db_session.rollback()
        return jsonify({"error": str(e)}), 500

@app.route('/createUser', methods=['POST'])
def create_user_route():
    data = request.get_json()
    
    id_token = data.get("idToken")
    if not id_token:
        return jsonify({"error": "Missing ID token"}), 400

    try:
        decoded_claims = auth.verify_id_token(id_token)
        firebase_uid = decoded_claims["uid"]
    except Exception as e:
        return jsonify({"error": "Invalid ID token: " + str(e)}), 401

    email = data.get("email")
    password = data.get("password")
    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    db_session = Session()
    try:
        new_user = create_user(db_session, email, password, firebase_uid=firebase_uid)
        return jsonify({"id": str(new_user.id), "email": new_user.email}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db_session.close()

@app.route('/sessionLogout', methods=['POST'])
def session_logout():

    response = jsonify({'message': 'Logged out'})
    response.set_cookie('session', '', max_age=0)
    return response

@app.route('/sessionLogin', methods=['POST', 'OPTIONS'])
def session_login():
    if request.method == 'OPTIONS':
        response = app.make_default_options_response()
        return response

    data = request.get_json()
    id_token = data.get('idToken')
    if not id_token:
        return jsonify({'error': 'Missing ID token'}), 400

    try:
        print("Verifying ID token...")
        # Verify the ID token
        decoded_claims = auth.verify_id_token(id_token)
        firebase_uid = decoded_claims["uid"]
        email = decoded_claims.get("email", "")
        print(f"Token verified. Firebase UID: {firebase_uid}, Email: {email}")

        # Check if user exists in database
        print("Checking database for user...")
        db_session = Session()
        try:
            user = get_user_by_firebase_uid(db_session, firebase_uid)
            print(f"User found: {user is not None}")
            
            # If user doesn't exist, create them
            if not user:
                print("Creating new user...")
                try:
                    user = create_user(db_session, email=email, password="", firebase_uid=firebase_uid)
                    db_session.commit()
                    print("User created successfully")
                except Exception as e:
                    print(f"Error creating user: {str(e)}")
                    db_session.rollback()
                    return jsonify({'error': 'Failed to create user'}), 500

            # Create session cookie
            print("Creating session cookie...")
            expires_in = 60 * 60 * 24 * 5  # 5 days
            session_cookie = auth.create_session_cookie(id_token, expires_in=expires_in)
            
            response = jsonify({'status': 'success'})
            
            # Determine if we're in production
            is_production = os.getenv("ENVIRONMENT") == "production"
            
            response.set_cookie(
                'session',
                session_cookie,
                max_age=expires_in,
                httponly=True,
                secure=is_production,  # Set to True in production with HTTPS
                samesite='Lax',
                path='/',
                domain=None
            )
            print("Session cookie created successfully")
            return response
        finally:
            db_session.close()
    except Exception as e:
        print(f"Session creation error: {str(e)}")
        return jsonify({'error': str(e)}), 401
    
@app.route('/chats', methods=['GET'])
def get_chats_route():
    try:
        # Get user from session
        user, error_message, status_code = get_user_from_session()
        if error_message:
            return jsonify({"error": error_message}), status_code

        # Get all chats for the user
        db_session = Session()
        try:
            chats = db_session.query(Chat).filter(Chat.userId == user.id).all()
            
            # Format the response
            formatted_chats = []
            for chat in chats:
                messages = []
                for message in chat.messages:
                    # Ensure content is a dictionary
                    content = message.content
                    if not isinstance(content, dict):
                        content = {"text": str(content)}
                    
                    messages.append({
                        "id": message.id,
                        "content": content,
                        "role": message.role,
                        "created_at": message.createdAt.isoformat()
                    })
                
                formatted_chats.append({
                    "id": chat.id,
                    "title": chat.title,
                    "messages": messages,
                    "created_at": chat.createdAt.isoformat()
                })
            
            return jsonify({"chats": formatted_chats})
        finally:
            db_session.close()
    except Exception as e:
        print(f"Error in get_chats_route: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/chat', methods=['POST'])
def save_chat_route():
    """Save a new chat."""
    try:
        # Get user from session
        user, error_message, status_code = get_user_from_session()
        if error_message:
            return jsonify({"error": error_message}), status_code

        data = request.json
        title = data.get('title')
        chat_id = data.get('id')

        if not title or not chat_id:
            return jsonify({"error": "Chat title and ID are required"}), 400

        db_session = Session()
        try:
            # Create new chat
            chat = Chat(
                id=chat_id,
                title=title,
                userId=user.id,
                createdAt=datetime.utcnow(),
                visibility='private'
            )
            db_session.add(chat)
            db_session.commit()

            # Format the response
            return jsonify({
                "id": chat.id,
                "title": chat.title,
                "created_at": chat.createdAt.isoformat(),
                "messages": []
            }), 201
        except Exception as e:
            db_session.rollback()
            raise e
        finally:
            db_session.close()
    except Exception as e:
        print(f"Error in save_chat_route: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/chats', methods=['DELETE'])
def delete_chat_param_missing():
    return jsonify({"error": "chat_id is required in the URL"}), 400

@app.route('/chat/<chat_id>', methods=['GET'])
def get_chat_by_id_route(chat_id):
    """Get a single chat by ID."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    db_session = Session()
    try:
        chat = db_session.query(Chat).filter(Chat.id == chat_id).first()
        if not chat:
            return jsonify({"error": "Chat not found"}), 404

        if str(chat.userId) != user["uid"]:
            return jsonify({"error": "Unauthorized"}), 401

        chat_data = {
            "id": str(chat.id),
            "createdAt": chat.createdAt.isoformat(),
            "title": chat.title,
            "userId": str(chat.userId),
            "visibility": chat.visibility
        }
        return jsonify(chat_data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db_session.close()

@app.route('/chat/<chat_id>', methods=['DELETE'])
def delete_chat_by_id_route(chat_id):
    """Delete a chat by its ID."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    try:
        delete_chat_by_id(db=Session(), chat_id=chat_id)
        return jsonify({"message": "Chat and its associated messages deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": f"Error deleting chat: {str(e)}"}), 500

@app.route('/messages/<chat_id>', methods=['GET'])
def get_messages_by_chat(chat_id):
    """Retrieve messages for a specific chat."""
    user_claims = verify_session_cookie()
    if isinstance(user_claims, dict) and "error" in user_claims:
        return user_claims

    db_session = Session()
    try:
        # 🔍 Step 1: Look up Postgres user using Firebase UID
        postgres_user = get_user_by_firebase_uid(db_session, user_claims["uid"])
        if not postgres_user:
            return jsonify({"error": "User not found"}), 404

        # ✅ Step 2: Get chat and compare using internal UUID
        chat = db_session.query(Chat).filter(Chat.id == chat_id).first()
        if not chat:
            return jsonify({"error": "Chat not found"}), 404

        if str(chat.userId) != str(postgres_user.id):
            print(f"Unauthorized: Chat.userId = {chat.userId}, Requesting user = {postgres_user.id}")
            return jsonify({"error": "Unauthorized"}), 401

        # ✅ Step 3: Return messages
        messages = get_messages_by_chat_id(db=db_session, chat_id=chat_id)
        if not messages:
            return jsonify([]), 200

        return jsonify([
            {
                "role": msg.role,
                "content": msg.content,
                "createdAt": msg.createdAt.isoformat()
            }
            for msg in messages
        ]), 200

    except Exception as e:
        print(f"Error in get_messages_by_chat: {str(e)}")
        return jsonify({"error": str(e)}), 500
    finally:
        db_session.close()



@app.route('/messages', methods=['POST', 'OPTIONS'])
def save_message_route():
    """Save a new message and generate an AI response using FAISS retrieval."""
    if request.method == 'OPTIONS':
        return '', 204  # Return empty response for preflight request
        
    try:
        # Get user from session
        user, error_message, status_code = get_user_from_session()
        if error_message:
            return jsonify({"error": error_message}), status_code

        data = request.json
        chat_id = data.get('chat_id')
        content = data.get('content')

        if not chat_id or not content:
            return jsonify({"error": "Chat ID and content are required"}), 400

        db_session = Session()
        try:
            # Create new message from user
            user_message = Message(
                id=str(uuid.uuid4()),
                chatId=chat_id,
                content=content,
                role='user',
                createdAt=datetime.utcnow()
            )
            db_session.add(user_message)
            db_session.commit()

            # Extract the text from content if it's an object
            query_text = content
            if isinstance(content, dict) and 'text' in content:
                query_text = content['text']

            # Generate AI response using FAISS if available
            ai_content = {"text": "I couldn't retrieve relevant information at this time."}
            
            if faiss_index is not None and metadata is not None:
                try:
                    # Import necessary functions from the FAISS retriever
                    from src.item_04_retriever_FAISS import raw_LLM_response
                    import os
                    
                    # Get the response using the FAISS retriever
                    # Pass the app directory where index.faiss is located
                    app_dir = "/app"  # This is where the index files are located
                    llm_response = raw_LLM_response(query_text, app_dir)
                    
                    if llm_response and 'result' in llm_response:
                        ai_content = {"text": llm_response['result']}
                        
                        # Add sources if available
                        if 'source_documents' in llm_response:
                            sources = []
                            for doc in llm_response['source_documents']:
                                if hasattr(doc, 'metadata') and 'source' in doc.metadata:
                                    sources.append(doc.metadata['source'])
                            
                            if sources:
                                ai_content["sources"] = sources
                except Exception as e:
                    print(f"Error generating RAG response: {str(e)}")
                    ai_content = {"text": f"I encountered an error while retrieving information: {str(e)}"}
                    # Fallback to OpenAI
                    try:
                        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                        response = client.chat.completions.create(
                            model="gpt-3.5-turbo",
                            messages=[{"role": "user", "content": query_text}]
                        )
                        assistant_content = response.choices[0].message.content
                        ai_content = {"text": assistant_content}
                    except Exception as openai_error:
                        print(f"Error with OpenAI fallback: {str(openai_error)}")
                        # Keep the original error message
            
            # Create AI response message
            ai_message = Message(
                id=str(uuid.uuid4()),
                chatId=chat_id,
                content=ai_content,
                role='assistant',
                createdAt=datetime.utcnow()
            )
            db_session.add(ai_message)
            db_session.commit()

            # Format the response to include both messages
            return jsonify({
                "id": user_message.id,
                "chat_id": user_message.chatId,
                "content": user_message.content,
                "role": user_message.role,
                "created_at": user_message.createdAt.isoformat(),
                "ai_response": {
                    "id": ai_message.id,
                    "chat_id": ai_message.chatId,
                    "content": ai_message.content,
                    "role": ai_message.role,
                    "created_at": ai_message.createdAt.isoformat()
                }
            }), 201
        except Exception as e:
            db_session.rollback()
            raise e
        finally:
            db_session.close()
    except Exception as e:
        print(f"Error in save_message_route: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/message/vote', methods=['POST'])
def vote_on_message():
    """Vote on a message in a chat."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.json
    chat_id = data.get('chatId')
    message_id = data.get('messageId')
    vote_type = data.get('type')

    if not chat_id or not message_id or not vote_type:
        return jsonify({"error": "Chat ID, message ID, and vote type are required"}), 400

    try:
        vote = vote_message(db=Session(), chat_id=chat_id, message_id=message_id, vote_type=vote_type)
        return jsonify(vote), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/vote/<chat_id>', methods=['GET'])
def get_votes_for_chat(chat_id):
    """Get votes for a particular chat."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    try:
        votes = get_votes_by_chat_id(db=Session(), chat_id=chat_id)
        return jsonify(votes), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/documents', methods=['GET'])
def get_documents_route():
    """Get documents belonging to authenticated user."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    user_id = user["uid"]
    document_id = request.args.get('id')

    if not document_id:
        return jsonify({'error': 'Missing id'}), 400

    documents = get_documents_by_id(db=Session(), id=document_id)
    if not documents:
        return jsonify({'error': 'Document not found'}), 404

    if documents[0]['userId'] != user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    return jsonify(documents), 200

@app.route('/documents', methods=['POST'])
def save_document_route():
    """Save a document for the authenticated user."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    user_id = user["uid"]
    document_id = request.args.get('id')
    if not document_id:
        return jsonify({'error': 'Missing id'}), 400

    data = request.get_json()
    content = data.get('content')
    title = data.get('title')
    kind = data.get('kind')

    if not content or not title or not kind:
        return jsonify({'error': 'Content, title, and kind are required'}), 400

    document = save_document(
        db=Session(),
        id=document_id,
        content=content,
        title=title,
        kind=kind,
        user_id=user_id
    )

    return jsonify(document), 200

@app.route('/documents', methods=['PATCH'])
def delete_documents_by_timestamp():
    """Delete documents after a certain timestamp for the authenticated user."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    user_id = user["uid"]
    document_id = request.args.get('id')
    if not document_id:
        return jsonify({'error': 'Missing id'}), 400

    data = request.get_json()
    timestamp_str = data.get('timestamp')

    if not timestamp_str:
        return jsonify({'error': 'Timestamp is required'}), 400

    from datetime import datetime
    try:
        timestamp = datetime.fromisoformat(timestamp_str)
    except ValueError:
        return jsonify({'error': 'Invalid timestamp format'}), 400

    documents = get_documents_by_id(db=Session(), id=document_id)

    if not documents:
        return jsonify({'error': 'Document not found'}), 404

    if documents[0]['userId'] != user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    delete_documents_by_id_after_timestamp(
        db=Session(),
        id=document_id,
        timestamp=timestamp
    )

    return jsonify({'message': 'Documents deleted successfully'}), 200

@app.route('/document/<document_id>', methods=['GET'])
def get_document_by_id_endpoint(document_id):
    """Retrieve a single document by its ID."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    try:
        doc = get_document_by_id(db=Session(), document_id=document_id)
        if not doc:
            return jsonify({"error": "Document not found"}), 404

        if doc['userId'] != user["uid"]:
            return jsonify({'error': 'Unauthorized'}), 401

        return jsonify(doc), 200
    except Exception as e:
        return jsonify({"error": f"Error retrieving document: {str(e)}"}), 500

@app.route('/suggestions', methods=['GET'])
def get_suggestions_route():
    """Fetch suggestions for a specific document ID."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    document_id = request.args.get('documentId')
    if not document_id:
        return jsonify({"error": "Document ID is required"}), 400

    try:
        suggestions = get_suggestions_by_document_id(document_id)
        if not suggestions:
            return jsonify([]), 200

        if suggestions[0]["userId"] != user["uid"]:
            return jsonify({"error": "Unauthorized"}), 401

        return jsonify(suggestions), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/suggestions', methods=['POST'])
def save_suggestions_endpoint():
    """Save suggestions for a specific document."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.get_json()
    document_id = data.get('documentId')
    original_text = data.get('originalText')
    suggested_text = data.get('suggestedText')
    description = data.get('description')
    user_id = user["uid"]

    if not document_id or not original_text or not suggested_text:
        return jsonify({"error": "documentId, originalText, and suggestedText are required"}), 400

    try:
        from datetime import datetime
        suggestions = [
            Suggestion(
                documentId=document_id,
                originalText=original_text,
                suggestedText=suggested_text,
                description=description,
                userId=user_id,
                documentCreatedAt=datetime.utcnow()
            )
        ]
        db_session = Session()
        save_suggestions(db_session, suggestions)
        return jsonify({"message": "Suggestions saved successfully"}), 201
    except Exception as e:
        return jsonify({"error": f"Error saving suggestions: {str(e)}"}), 500

@app.route('/delete-trailing-messages', methods=['POST'])
def delete_trailing_messages():
    """Delete messages after a given timestamp in a chat."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.get_json()
    message_id = data.get('id')

    if not message_id:
        return jsonify({"error": "Message ID is required"}), 400

    msg = get_message_by_id(id=message_id)
    if not msg:
        return jsonify({"error": "Message not found"}), 404

    delete_messages_by_chat_id_after_timestamp(chatId=msg.chatId, timestamp=msg.createdAt)
    return jsonify({"message": "Trailing messages deleted"}), 200

@app.route('/update-chat-visibility', methods=['POST'])
def update_chat_visibility():
    """Update the visibility status of a chat."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.get_json()
    chat_id = data.get('chatId')
    visibility = data.get('visibility')

    if not chat_id or not visibility:
        return jsonify({"error": "Chat ID and visibility are required"}), 400

    update_chat_visibility_by_id(db=Session(), chat_id=chat_id, visibility=visibility)

    return jsonify({"message": "Chat visibility updated successfully"}), 200

@app.route('/save-model-id', methods=['POST'])
def save_model_id():
    """Save the selected AI model ID. Optionally protect this route."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.get_json()
    model_id = data.get('model')

    if not model_id:
        return jsonify({"error": "Model ID is required"}), 400

    return jsonify({"message": f"Model ID {model_id} saved successfully"}), 200

@app.route('/generate-title', methods=['POST'])
def generate_title_from_message():
    """Generate a short title from the user's first message."""
    user = verify_session_cookie()
    if isinstance(user, dict) and "error" in user:
        return user

    data = request.get_json()
    message = data.get('message')

    if not message:
        return jsonify({"error": "Message is required"}), 400

    title = message[:80]
    return jsonify({"title": title}), 200


@app.route('/ai-chat', methods=['POST']) 
def ai_chat():
    try:
        # ✅ Session validation (unchanged)
        user = get_user_from_session()
        if "error" in user:
            return jsonify(user), 401

        # 🔄 CHANGED: cleaned up variable names
        data = request.get_json()
        print("Received data:", data)

        chat_id = data.get("id")
        user_message = data.get("userMessage")
        conversation = data.get("messages", [])  # ✅ Expect full conversation history now

        if not user_message:
            return jsonify({"error": "User message is required"}), 400

        db_session = Session()

        # ✅ Chat retrieval or creation
        chat = get_chat_by_id(db_session, chat_id) if chat_id else None
        if not chat:
            postgres_user = get_user_by_firebase_uid(db_session, user["uid"])
            if not postgres_user:
                return jsonify({"error": "User not found in database"}), 404

            chat = save_chat(db_session, user_id=postgres_user.id, title="New Chat")  # 🔄 CHANGED: added fallback title
            chat_id = str(chat.id)

        # ✅ Save user message
        user_msg = Message(
            id=str(uuid.uuid4()),
            chatId=chat_id,
            role="user",
            content=str(user_message),  # 🔄 CHANGED: explicitly convert to string
            createdAt=datetime.utcnow()
        )
        save_messages(db_session, messages=[user_msg])

        # ✅ Build prompt for OpenAI
        conversation_payload = conversation.copy()  # 🔄 CHANGED: now includes full history from frontend
        conversation_payload.append({"role": "user", "content": user_message})

        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=conversation_payload
        )
        assistant_content = response.choices[0].message.content
        print("OpenAI responded with:", assistant_content)

        # ✅ Save assistant message
        assistant_msg = Message(
            id=str(uuid.uuid4()),
            chatId=chat_id,
            role="assistant",
            content=str(assistant_content),  # 🔄 CHANGED: explicitly convert to string
            createdAt=datetime.utcnow()
        )
        save_messages(db_session, messages=[assistant_msg])

        # 🔄 CHANGED: Return both assistant reply and chatId (chatId may be newly created)
        return jsonify({
            "assistant": assistant_content,
            "chatId": chat_id
        }), 200

    except Exception as e:
        print("Error in /ai-chat:", str(e))
        return jsonify({"error": "Server error: " + str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)