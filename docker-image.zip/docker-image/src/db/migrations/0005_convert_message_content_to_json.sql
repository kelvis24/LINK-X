-- Convert Message content column from text to json
DO $$
BEGIN
    -- Check if content column exists and is of type text
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'Message' 
        AND column_name = 'content'
        AND data_type = 'text'
    ) THEN
        -- Create a temporary column for json content
        ALTER TABLE "Message" ADD COLUMN content_json jsonb;
        
        -- Convert existing text content to json
        UPDATE "Message" 
        SET content_json = jsonb_build_object('text', content);
        
        -- Drop the old text column
        ALTER TABLE "Message" DROP COLUMN content;
        
        -- Rename the new column to content
        ALTER TABLE "Message" RENAME COLUMN content_json TO content;
        
        -- Add NOT NULL constraint
        ALTER TABLE "Message" ALTER COLUMN content SET NOT NULL;
    END IF;
END
$$; 