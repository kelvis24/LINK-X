-- Ensure Message content column is properly set as json type
DO $$
BEGIN
    -- Drop the content column if it exists (regardless of type)
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'Message' 
        AND column_name = 'content'
    ) THEN
        ALTER TABLE "Message" DROP COLUMN content;
    END IF;

    -- Add the content column as json type
    ALTER TABLE "Message" ADD COLUMN content json NOT NULL;
END
$$; 