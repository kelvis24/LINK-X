-- Fix existing message content data
DO $$
BEGIN
    -- Check if there are any messages with non-JSON content
    IF EXISTS (
        SELECT 1 FROM "Message" 
        WHERE content IS NOT NULL 
        AND NOT (content::text ~ '^\{.*\}$' OR content::text ~ '^\[.*\]$')
    ) THEN
        -- Update messages with non-JSON content to proper JSON format
        UPDATE "Message"
        SET content = json_build_object('text', content::text)
        WHERE NOT (content::text ~ '^\{.*\}$' OR content::text ~ '^\[.*\]$');
    END IF;
END
$$; 