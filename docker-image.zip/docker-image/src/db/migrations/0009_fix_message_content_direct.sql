-- Direct fix for message content data
DO $$
BEGIN
    -- First, ensure the content column is of type jsonb
    ALTER TABLE "Message" 
    ALTER COLUMN content TYPE jsonb 
    USING CASE 
        WHEN content IS NULL THEN '{"text": ""}'::jsonb
        WHEN jsonb_typeof(content::jsonb) IS NULL THEN jsonb_build_object('text', content::text)
        ELSE content::jsonb
    END;
END
$$; 