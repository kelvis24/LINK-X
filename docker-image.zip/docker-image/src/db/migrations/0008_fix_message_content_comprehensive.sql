-- Comprehensive fix for message content data
DO $$
DECLARE
    msg RECORD;
    fixed_content JSONB;
BEGIN
    -- Create a backup table if it doesn't exist
    CREATE TABLE IF NOT EXISTS "Message_backup" (
        LIKE "Message" INCLUDING ALL
    );

    -- Copy existing data to backup
    INSERT INTO "Message_backup" 
    SELECT * FROM "Message";

    -- Process each message
    FOR msg IN SELECT id, content FROM "Message" LOOP
        BEGIN
            -- Try to cast the content to JSONB directly
            fixed_content := msg.content::jsonb;
        EXCEPTION WHEN OTHERS THEN
            -- If casting fails, wrap the content in a JSON object
            BEGIN
                fixed_content := jsonb_build_object('text', msg.content::text);
            EXCEPTION WHEN OTHERS THEN
                -- If even that fails, use a default value
                fixed_content := jsonb_build_object('text', 'Invalid content');
            END;
        END;

        -- Update the message with the fixed content
        UPDATE "Message"
        SET content = fixed_content
        WHERE id = msg.id;
    END LOOP;
END
$$; 