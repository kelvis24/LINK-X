-- Alter the firebase_uid column in the User table to be VARCHAR(128)
ALTER TABLE "User" ALTER COLUMN firebase_uid TYPE VARCHAR(128); 