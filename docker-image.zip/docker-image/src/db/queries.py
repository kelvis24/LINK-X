from sqlalchemy import select, and_, desc, asc
from sqlalchemy.orm import Session
from src.db.schema import User, Chat, Message, Vote, Document, Suggestion, Onboarding
from werkzeug.security import generate_password_hash, check_password_hash
from typing import List, Optional
from datetime import date, datetime
import uuid

def get_user_by_email(db: Session, email: str):
    try:
        result = db.execute(select(User).filter_by(email=email)).scalars().first()
        return result
    except Exception as e:
        print(f"Error retrieving user: {e}")
        raise

def create_user(db: Session, email: str, password: str, firebase_uid: str = None) -> User:
    """Create a new user."""
    try:
        # Hash the password if provided
        hashed_password = None
        if password:
            hashed_password = generate_password_hash(password)

        # Create new user
        new_user = User(
            id=uuid.uuid4(),
            email=email,
            password=hashed_password,
            firebase_uid=firebase_uid[:128] if firebase_uid else None  # Truncate to 128 characters
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        return new_user
    except Exception as e:
        db.rollback()
        raise e

def save_chat(db: Session, user_id: str, title: str):

    try:
        new_chat = Chat(userId=user_id, title=title)
        db.add(new_chat)
        db.commit()
        return new_chat
    except Exception as e:
        print(f"Error saving chat: {e}")
        raise

def delete_chat_by_id(db: Session, chat_id: str):

    try:
        db.query(Vote).filter(Vote.chat_id == chat_id).delete()
        db.query(Message).filter(Message.chat_id == chat_id).delete()
        db.query(Chat).filter(Chat.id == chat_id).delete()
        db.commit()
    except Exception as e:
        print(f"Error deleting chat: {e}")
        raise

def get_chats_by_user_id(db: Session, user_id: str):

    try:
        return db.execute(select(Chat).filter_by(userId=user_id).order_by(desc(Chat.createdAt))).scalars().all()
    except Exception as e:
        print(f"Error retrieving chats by user: {e}")
        raise

def get_chat_by_id(db: Session, chat_id: str):

    try:
        return db.execute(select(Chat).filter_by(id=chat_id)).scalars().first()
    except Exception as e:
        print(f"Error retrieving chat: {e}")
        raise

def save_messages(db: Session, messages: List[dict]):
    """Save multiple messages for a chat."""
    try:
        message_objects = []
        for msg in messages:
            # Ensure content is properly formatted as JSON
            content = msg.get('content')
            if not isinstance(content, (dict, list)):
                content = {"text": str(content)}
            
            message = Message(
                id=msg.get('id', str(uuid.uuid4())),
                chatId=msg['chatId'],
                role=msg['role'],
                content=content,
                createdAt=msg.get('createdAt', datetime.utcnow())
            )
            message_objects.append(message)
        
        db.add_all(message_objects)
        db.commit()
        return message_objects
    except Exception as e:
        print(f"Error saving messages: {e}")
        raise

def get_messages_by_chat_id(db: Session, chat_id: str):

    try:
        return db.execute(select(Message).filter_by(chatId=chat_id).order_by(asc(Message.createdAt))).scalars().all()
    except Exception as e:
        print(f"Error retrieving messages by chat ID: {e}")
        raise

def vote_message(db: Session, chat_id: str, message_id: str, vote_type: str):

    try:
        existing_vote = db.execute(select(Vote).filter_by(messageId=message_id)).scalars().first()

        if existing_vote:
            existing_vote.is_upvoted = vote_type == 'up'
            db.commit()
        else:
            new_vote = Vote(chatId=chat_id, messageId=message_id, isUpvoted=(vote_type == 'up'))
            db.add(new_vote)
            db.commit()
    except Exception as e:
        print(f"Error voting on message: {e}")
        raise

def get_votes_by_chat_id(db: Session, chat_id: str):

    try:
        return db.execute(select(Vote).filter_by(chatId=chat_id)).scalars().all()
    except Exception as e:
        print(f"Error retrieving votes by chat ID: {e}")
        raise

def save_document(db: Session, user_id: str, title: str, kind: str, content: str):

    try:
        new_document = Document(userId=user_id, title=title, kind=kind, content=content)
        db.add(new_document)
        db.commit()
        return new_document
    except Exception as e:
        print(f"Error saving document: {e}")
        raise

def get_documents_by_id(db: Session, document_id: str):

    try:
        return db.execute(select(Document).filter_by(id=document_id).order_by(asc(Document.createdAt))).scalars().all()
    except Exception as e:
        print(f"Error retrieving documents by ID: {e}")
        raise

def get_document_by_id(db: Session, document_id: str):

    try:
        return db.execute(select(Document).filter_by(id=document_id).order_by(desc(Document.createdAt))).scalars().first()
    except Exception as e:
        print(f"Error retrieving document: {e}")
        raise

def delete_documents_by_id_after_timestamp(db: Session, document_id: str, timestamp: str):

    try:
        db.query(Suggestion).filter(and_(Suggestion.documentId == document_id, Suggestion.createdAt > timestamp)).delete()
        db.query(Document).filter(and_(Document.id == document_id, Document.createdAt > timestamp)).delete()
        db.commit()
    except Exception as e:
        print(f"Error deleting documents: {e}")
        raise

def save_suggestions(db: Session, suggestions: list):

    try:
        db.add_all(suggestions)
        db.commit()
    except Exception as e:
        print(f"Error saving suggestions: {e}")
        raise

def get_suggestions_by_document_id(db: Session, document_id: str):

    try:
        return db.execute(select(Suggestion).filter_by(documentId=document_id)).scalars().all()
    except Exception as e:
        print(f"Error retrieving suggestions by document ID: {e}")
        raise

def get_message_by_id(db: Session, message_id: str):

    try:
        return db.execute(select(Message).filter_by(id=message_id)).scalars().first()
    except Exception as e:
        print(f"Error retrieving message: {e}")
        raise

def delete_messages_by_chat_id_after_timestamp(db: Session, chat_id: str, timestamp: str):

    try:
        db.query(Message).filter(and_(Message.chatId == chat_id, Message.createdAt >= timestamp)).delete()
        db.commit()
    except Exception as e:
        print(f"Error deleting messages: {e}")
        raise

def update_chat_visibility_by_id(db: Session, chat_id: str, visibility: str):

    try:
        chat = db.execute(select(Chat).filter_by(id=chat_id)).scalars().first()
        if chat:
            chat.visibility = visibility
            db.commit()
            return chat
        else:
            print(f"Chat with ID {chat_id} not found.")
            raise Exception("Chat not found")
    except Exception as e:
        print(f"Error updating chat visibility: {e}")
        raise

def create_onboarding(
    db: Session,
    user_id: str,
    name: str,
    answers: List[Optional[str]],
    quizzes: bool = False
) -> Onboarding:

    try:
        onboarding_record = Onboarding(
            userId=user_id,
            name=name,
            answers=answers,
            quizzes=quizzes,
        )
        db.add(onboarding_record)
        db.commit()
        db.refresh(onboarding_record)
        return onboarding_record
    except Exception as e:
        print("Error creating onboarding record:", e)
        db.rollback()
        raise e
    
def get_onboarding(db: Session, user_id: str) -> Optional[Onboarding]:

    try:
        return db.execute(
            select(Onboarding).filter_by(userId=user_id)
        ).scalars().first()
    except Exception as e:
        print("Error retrieving onboarding record:", e)
        raise e

def get_user_by_firebase_uid(db: Session, firebase_uid: str):
    try:
        result = db.execute(select(User).filter_by(firebase_uid=firebase_uid)).scalars().first()
        return result
    except Exception as e:
        print("Error retrieving user by firebase_uid:", e)
        raise

def update_user_by_firebase_uid(db: Session, firebase_uid: str, update_data: dict):

    try:
        user = get_user_by_firebase_uid(db, firebase_uid)
        if not user:
            raise Exception("User not found")
        if "email" in update_data:
            user.email = update_data["email"]
        if "password" in update_data:
            user.password = generate_password_hash(update_data["password"])
        db.commit()
        db.refresh(user)
        return user
    except Exception as e:
        db.rollback()
        raise e

def delete_user_by_firebase_uid(db: Session, firebase_uid: str):

    try:
        user = get_user_by_firebase_uid(db, firebase_uid)
        if not user:
            raise Exception("User not found")
        db.delete(user)
        db.commit()
    except Exception as e:
        db.rollback()
        raise e

def update_onboarding_by_user_id(db: Session, user_id: str, update_data: dict):

    try:
        onboarding = db.execute(
            select(Onboarding).filter_by(userId=user_id)
        ).scalars().first()
        if not onboarding:
            raise Exception("Onboarding record not found")
        if "name" in update_data:
            onboarding.name = update_data["name"]
        if "answers" in update_data:
            onboarding.answers = update_data["answers"]
        if "quizzes" in update_data:
            onboarding.quizzes = update_data["quizzes"]
        db.commit()
        db.refresh(onboarding)
        return onboarding
    except Exception as e:
        db.rollback()
        raise e

def delete_onboarding_by_user_id(db: Session, user_id: str):

    try:
        onboarding = db.execute(
            select(Onboarding).filter_by(userId=user_id)
        ).scalars().first()
        if not onboarding:
            raise Exception("Onboarding record not found")
        db.delete(onboarding)
        db.commit()
    except Exception as e:
        db.rollback()
        raise e