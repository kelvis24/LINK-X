-- Add firebase_uid column to User table if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'User' AND column_name = 'firebase_uid'
    ) THEN
        ALTER TABLE "User" ADD COLUMN firebase_uid VARCHAR(128);
    END IF;
END
$$; 