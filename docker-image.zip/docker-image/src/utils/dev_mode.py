import uuid
from datetime import datetime
from src.db.schema import User
from src.db.queries import get_user_by_email, get_user_by_firebase_uid

def ensure_dev_user(db_session):
    """Ensure development user exists in the database."""
    try:
        # Try to get existing dev user by email
        dev_user = get_user_by_email(db_session, 'dev@example.com')
        if dev_user:
            return dev_user

        # Try to get by firebase UID
        dev_user = get_user_by_firebase_uid(db_session, 'dev-user-id')
        if dev_user:
            return dev_user

        # Create new dev user if doesn't exist
        dev_user = User(
            id=uuid.uuid4(),
            email='dev@example.com',
            firebase_uid='dev-user-id',
            password='dev-password',  # This is just for development
            created_at=datetime.utcnow()
        )
        db_session.add(dev_user)
        db_session.commit()
        db_session.refresh(dev_user)
        return dev_user
    except Exception as e:
        print(f"Error ensuring dev user: {e}")
        db_session.rollback()
        return None 